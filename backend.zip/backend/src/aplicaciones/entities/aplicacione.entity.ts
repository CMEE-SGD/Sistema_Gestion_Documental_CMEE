export class Aplicacione {}
