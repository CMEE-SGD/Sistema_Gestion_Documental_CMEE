export class CreateAplicacioneDto {}
