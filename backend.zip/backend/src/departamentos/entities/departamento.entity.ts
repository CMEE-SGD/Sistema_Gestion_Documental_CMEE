export class Departamento {}
