export class PersonaPuesto {}
