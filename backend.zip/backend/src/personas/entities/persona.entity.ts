export class Persona {}
