export class Puesto {}
