export class CreateDocumentoDto {}
