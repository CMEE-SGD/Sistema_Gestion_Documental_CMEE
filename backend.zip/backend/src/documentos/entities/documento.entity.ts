export class Documento {}
