export class Grupo {}
